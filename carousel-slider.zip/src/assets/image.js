export const images = {
    image1: require('../assets/image-1.png'),
    image2:require('../assets/image-2.png'),
    image3: require('../assets/image-3.png'),
    image4: require('../assets/image-4.png'),
    image5: require('../assets/image-5.png'),
}